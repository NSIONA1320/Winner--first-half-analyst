WINNER FIRST HALF ANALYST — version de démarrage

Cette archive contient l'interface de départ de l'application.
Elle n'affiche pas encore les vrais calendriers ou statistiques.
Aucun pronostic n'est fabriqué.

Fichiers :
- index.html : interface française
- manifest.webmanifest : paramètres d'installation PWA
- sw.js : cache hors ligne de base

Prochaine étape : publier avec GitHub Pages, puis connecter une source de données football gratuite avec ses limites et conditions. Ne jamais publier une clé API secrète dans le code du navigateur.
